# 필요한 라이브러리를 가져옵니다.
# 'transformers'와 'torch'는 자연어 처리를 위한 프레임워크입니다.
from transformers import pipeline  # Huggingface의 모델 사용을 위해 pipeline을 가져옵니다.
import torch  # PyTorch 라이브러리

# 감정 분석을 위한 파이프라인을 만들기 위해 'pipeline' 함수 사용
# 'sentiment-analysis' 태스크로 정의된 사전 훈련된 모델을 로드합니다.
sentiment_analyzer = pipeline("sentiment-analysis")

# 분석할 문장을 정의합니다.
sentences = [----]

# 각 문장에 대해 감정 분석을 수행하고 결과를 프린트합니다.
for ---- in ----:
    ----
    ----

# 결과 해석
# 감정 분석 결과는 리스트 형태로 반환됩니다. 
# 각 리스트 아이템은 'label'(긍정/부정)과 'score'(확신도)가 포함된 딕셔너리입니다.