# 필요한 라이브러리를 임포트합니다.
from chatterbot import ChatBot  # ChatterBot 라이브러리에서 ChatBot 클래스를 임포트합니다.
from chatterbot.trainers import ListTrainer  # 리스트 형식의 학습을 위한 ListTrainer 임포트합니다.

# ChatBot 객체를 생성합니다.
chatbot = ChatBot("Learning Bot")  # 'Learning Bot'이라는 이름의 ChatBot 객체를 생성합니다.

# 학습 데이터를 준비합니다.
conversation = [  # 간단한 대화 문장을 리스트로 정의합니다.
    ----,  # 'Hello'
    ----,  # 'Hi there!'
    ----,  # 'How are you doing?'
    ----,  # 'I'm doing great.'
    ----,  # 'That is good to hear.'
    ----,  # 'Thank you.'
    ----   # 'You're welcome.'
]

# ChatBot에게 학습 데이터를 학습시킵니다.
trainer = ListTrainer(chatbot)  # ListTrainer 클래스로 트레이너 객체를 생성합니다.
trainer.train(conversation)  # 준비한 대화 문장을 ChatBot 객체에 학습시킵니다.

# ChatBot과의 대화를 테스트합니다.
response = chatbot.get_response("Hello")  # 'Hello' 라는 입력에 대한 ChatBot의 응답을 가져옵니다.
print("Bot:", response)  # ChatBot의 응답을 출력합니다.

response = chatbot.get_response("How are you doing?")  # 'How are you doing?' 라는 입력에 대한 ChatBot의 응답을 가져옵니다.
print("Bot:", response)  # ChatBot의 응답을 출력합니다.

# 유저의 입력을 받아서 ChatBot과 대화합니다.
while True:  # 무한 반복문을 사용하여 계속해서 대화를 주고받습니다.
    try:
        user_input = input("You: ")  # 유저의 입력을 받습니다.
        response = ----  # 입력에 대한 ChatBot의 응답을 가져옵니다.
        print("Bot:", response)  # ChatBot의 응답을 출력합니다.
    except (KeyboardInterrupt, EOFError, SystemExit):  # 키보드 인터럽트나 EOFError, 또는 시스템 종료가 발생하면
        break  # 반복문을 종료합니다.