# 필요한 라이브러리 임포트
import re  # 정규 표현식을 사용하기 위해 re 모듈을 임포트
from nltk.corpus import stopwords  # 불용어 처리를 위해 nltk에서 stopwords를 임포트
from nltk.tokenize import word_tokenize  # 단어 토크나이징을 위해 nltk에서 word_tokenize를 임포트
from nltk.stem import PorterStemmer  # 어간 추출을 위해 nltk에서 PorterStemmer를 임포트
from nltk.stem import WordNetLemmatizer  # 표제어 추출을 위해 nltk에서 WordNetLemmatizer를 임포트
import string  # 구두점 처리를 위해 string 모듈을 임포트

# 문장 예시
sentences = [
    "Natural Language Processing (NLP) is fun!",
    "I love learning new skills.",
    "Can you believe how amazing NLP is?"
]

def preprocess_text(text):
    ----  # 소문자로 변환

    ----  # 구두점 제거

    ----  # 숫자 제거

    ----  # 불용어 제거
    ----
    ----
    ----

    ----  # 어간 추출
    ----

    ----  # 표제어 추출
    ----

    return lemmatized_words

# 예시 문장에 대해 전처리 실행
for sentence in sentences:  # 주어진 문장을 순차적으로 반복
    ----  # 원본 문장 출력
    ----  # 전처리된 단어 출력
    ----