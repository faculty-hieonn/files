# 필요한 라이브러리 임포트
import spacy
from spacy.tokens import DocBin
from collections import Counter

# spacy 모델 로드 (사용할 언어에 맞는 모델을 다운로드 받아야 함)
nlp = spacy.load('en_core_web_sm')

# 텍스트 데이터 설정
texts = ["Apple is looking at buying U.K. startup for $1 billion",
         "I love coding in Python", 
         "Google's new AI chatbot is amazing"]

# 각 문장에 대해 처리 수행
for text in texts:
    doc = nlp(text)  # 텍스트를 spacy의 Doc 객체로 변환
    
    # 명사구(Noun chunks) 추출 및 출력
    print(f"Text: {text}")
    print("Noun chunks:")
    for chunk in doc.noun_chunks:
        print(chunk.text)
    
    # 품사 태깅(POS tagging) 출력
    print("\nPOS tagging:")
    for token in doc:
        print(f"{token.text} - {token.pos_} ({token.tag_}): {token.dep_}")
    
    # 개체명 인식(NER) 출력
    print("\nNamed Entities:")
    for ent in doc.ents:
        print(f"{ent.text} - {ent.label_}")
    print("\n" + "-"*30 + "\n")

# 단어 임베딩 확인
# 첫번째 텍스트에 대해 단어와 각 단어에 대한 벡터를 출력
print("Word Embeddings for the first text:")
doc = nlp(texts[0])
for token in doc:
    print(f"Word: {token.text}, Vector: {token.vector[:5]}...")  # 벡터의 처음 5개 요소만 출력
