# 자연어 처리 및 데이터 프레임 조작을 위한 pandas 라이브러리를 불러옵니다.
import pandas as pd
# 자연어 처리의 핵심 라이브러리인 NLTK와 다양한 텍스트 전처리 기능을 사용하기 위해 호출합니다.
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# 텍스트 전처리를 담당할 클래스를 정의합니다.
class TextPreprocessor:
    def __init__(self, text):
        # 클래스 초기화 시 입력된 텍스트를 저장합니다.
        self.text = text
        # nltk의 불용어 리스트를 가져옵니다.
        ----
        # 단어 원형 복원을 위한 객체를 생성합니다.
        ----

    # 문장 단위로 텍스트를 나누는 메서드입니다.
    def tokenize_sentences(self):
        return ----

    # 단어 단위로 텍스트를 나누는 메서드입니다.
    def tokenize_words(self):
        return ----

    # 불용어를 제거하는 메서드입니다.
    def remove_stopwords(self, tokens):
        return [word for word in tokens if ----]

    # 단어를 원형으로 복원하는 메서드입니다.
    def lemmatize_words(self, tokens):
        return [self.lemmatizer.lemmatize(word) for word in ----]

    # 텍스트를 전처리하는 종합 메서드입니다.
    def preprocess(self):
        # 단어를 토큰화합니다.
        tokens = ----
        # 불용어를 제거합니다.
        tokens = ----
        # 원형으로 복원합니다.
        tokens = ----
        return ----

# 사용 예시입니다.
if __name__ == "__main__":
    # 처리할 텍스트를 정의합니다.
    text = ----
    # 전처리 객체를 생성합니다.
    ----
    # 문장 단위 토큰화 결과를 출력합니다.
    ----
    # 단어 단위 토큰화 결과를 출력합니다.
    ----
    # 종합 전처리 결과를 출력합니다.
    ----
